import './App.css';
import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Navbar from './components/Navbar';
import Form from './components/Form'

function Content () {
  return (
    <>
      <h2 style={{ color: 'blue', backgroundColor: 'red' }}>Content</h2>
    </>
  )
}

function App() {
  const [isOn, setOn] = useState(true);

  function setLampu () {
    setOn(!isOn)
  }

  return (
    <div className="App">
      <Navbar title="Aplikasi Mancing" />
      
      <Form />
      <Content />

      {
        isOn ? "Hello lampu nyala": "Hello lampu mati"
      }

      <button onClick={setLampu}>lampu</button>
    </div>
  );
}

export default App;
